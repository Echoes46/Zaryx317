package io.runerealm.content.commands.all;

import io.runerealm.content.commands.Command;
import io.runerealm.model.entity.player.Player;
import io.runerealm.model.entity.player.mode.Mode;
import io.runerealm.model.entity.player.mode.ModeType;

public class Foundry extends Command {

    @Override
    public void execute(Player c, String commandName, String input) {
        if (c.getMode().equals(Mode.forType(ModeType.GROUP_WILDYMAN)) || c.getMode().equals(Mode.forType(ModeType.WILDYMAN))) {
            return;
        }
        c.getPA().startTeleport(3115, 3503, 0, "foundry", false);
    }
}
