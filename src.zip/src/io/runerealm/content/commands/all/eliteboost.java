package io.runerealm.content.commands.all;

import io.runerealm.content.commands.Command;
import io.runerealm.model.entity.player.Player;

import java.util.concurrent.TimeUnit;

/**
 * @author RuneRealm
 * @social Discord: RuneRealm
 * Website: www.runecrest.com
 * @since 31/03/2024
 */
public class eliteboost extends Command {

    @Override
    public void execute(Player player, String commandName, String input) {
        if (player.EliteCentCooldown < System.currentTimeMillis()) {
            player.EliteCentBoost = 6000;

            player.EliteCentCooldown = (System.currentTimeMillis() + TimeUnit.DAYS.toMillis(1));
        } else {
            player.sendMessage("This boost is on cooldown!");
        }
    }
}
