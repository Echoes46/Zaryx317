package io.runerealm.content.commands.all;

import java.util.Optional;

import io.runerealm.content.commands.Command;
import io.runerealm.model.entity.player.Player;

/**
 * Opens the vote page in the default web browser.
 * 
 * @author Emiel
 */
public class Discord extends Command {

	@Override
	public Optional<String> getDescription() {
		return Optional.of("Invites you to our Discord server");
	}

	@Override
	public void execute(Player player, String commandName, String input) {
		player.getPA().sendFrame126("https://discord.gg/PWV3Y4GgCx", 12000);
		
	}

}
