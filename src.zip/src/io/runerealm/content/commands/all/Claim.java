package io.runerealm.content.commands.all;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import io.runerealm.Configuration;
import io.runerealm.Server;
import io.runerealm.content.commands.Command;
import io.runerealm.content.deals.AccountBoosts;
import io.runerealm.content.deals.BonusItems;
import io.runerealm.content.dialogue.DialogueBuilder;
import io.runerealm.content.dialogue.DialogueOption;
import io.runerealm.model.entity.player.Player;
import io.runerealm.model.entity.player.PlayerHandler;
import io.runerealm.model.entity.player.Right;
import io.runerealm.sql.MainSql.StoreDonation;
import io.runerealm.sql.dailytracker.TrackerType;
import io.runerealm.sql.donation.query.ClaimDonationsQuery;
import io.runerealm.sql.donation.model.DonationItem;
import io.runerealm.sql.donation.model.DonationItemList;
import io.runerealm.sql.donation.query.GetDonationsQuery;
import io.runerealm.util.logging.player.DonatedLog;

/**
 * Changes the password of the player.
 *
 * @author Emiel
 *
 */
public class Claim extends Command {

	public static void claimDonations(Player player) {
		Server.getDatabaseManager().exec(Server.getConfiguration().getStoreDatabase(), (context, connection) -> {
			DonationItemList donationItemList = new GetDonationsQuery(player.getLoginName()).execute(context, connection);

			player.addQueuedAction(plr -> {
				List<DonationItem> claimed = new ArrayList<>();

				try {
					donationItemList.newDonations().forEach(item -> {
						if (giveDonationItem(player, item)) {
							claimed.add(item);
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (!claimed.isEmpty()) {
						Server.getDatabaseManager().exec(Server.getConfiguration().getStoreDatabase(), new ClaimDonationsQuery(player, claimed));
					}
				}
			});

			return null;
		});
	}

	public static boolean giveDonationItem(Player plr, DonationItem item) {
		int itemId = item.getItemId();
		int itemQuantity = item.getItemAmount();
		if (plr.getItems().hasRoomInInventory(itemId, itemQuantity)) {
			plr.getItems().addItem(itemId, itemQuantity);
			Server.getLogging().write(new DonatedLog(plr, item));
			plr.getDonationRewards().increaseDonationAmount(item.getItemCost() * itemQuantity);
			plr.sendMessage("You've received x" + item.getItemAmount() + " " + item.getItemName());
			plr.start(new DialogueBuilder(plr).option("Would you like to announce your donation?",
					new DialogueOption("Yes, show my support!", p -> {
						PlayerHandler.message(Right.STAFF_MANAGER, "@blu@[" + p.getDisplayName() + "]@pur@ has just donated for " + itemQuantity + " " + item.getItemName() + "!");
					}), new DialogueOption("No thank you, keep me out the loop.", p -> p.getPA().closeAllWindows())));
			return true;
		} else {
			plr.sendMessage("Not enough room in inventory to claim " + item.getItemName() + ", make space and try again.");
			return false;
		}
	}

	@Override
	public void execute(Player c, String commandName, String input) {
		new java.lang.Thread() {
			public void run() {
				try {
					com.everythingrs.donate.Donation[] donations = com.everythingrs.donate.Donation.donations("7kf0qxIzkYsy2oGhGqwmEFxQuFYVawJuSkABfgmHExKgYLZ5aj7VzjXP6NK4WicRWP0ZmIKE", c.getDisplayName());
					if (donations.length == 0) {
						c.sendMessage("You currently don't have any items waiting. You must donate first!");
						c.getPA().sendFrame126(Configuration.STORE_LINK, 12000);
						return;
					}
					if (donations[0].message != null) {
						c.sendMessage(donations[0].message);
						c.getPA().sendFrame126(Configuration.STORE_LINK, 12000);
						return;
					}
					for (com.everythingrs.donate.Donation donate: donations) {
						c.getDonationRewards().increaseDonationAmount((int) donate.product_price);
						c.sendMessage("You've received x" + donate.amount_purchased + " " + donate.product_name);
						c.setStoreDonated((long) (c.getStoreDonated() + donate.product_price));
						c.amDonated += (int) donate.product_price;
						PlayerHandler.executeGlobalMessage( "@blu@[" + c.getDisplayName() + "]@pur@ just donated for " + donate.amount_purchased + "x " + donate.product_name + "!");

						TrackerType.DONATIONS.addTrackerData((int) donate.product_price);

						BonusItems.handleDonation(c, donate.product_id, donate.product_amount);
						AccountBoosts.addWeeklyDono(c, (int) donate.product_price);
						c.setCosmeticCredits((long) (c.getCosmeticCredits() + donate.product_price));
						c.getItems().addItem(donate.product_id, donate.product_amount);
					}
					c.sendMessage("Thank you for donating & Support RuneRealm!");
				} catch (Exception e) {
					c.sendMessage("Api Services are currently offline. Please check back shortly");
					e.printStackTrace();
				}
			}
		}.start();
	}

	@Override
	public Optional<String> getDescription() {
		return Optional.of("Claim your donated item.");
	}
}
