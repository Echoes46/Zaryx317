package io.runerealm.content.commands.all;

import io.runerealm.content.commands.Command;
import io.runerealm.content.worldevent.WorldEventInformation;
import io.runerealm.model.entity.player.Player;

public class events extends Command {
    @Override
    public void execute(Player player, String commandName, String input) {
        WorldEventInformation.openInformationInterface(player);
    }
}
