package io.runerealm.content.commands.admin;

import io.runerealm.Server;
import io.runerealm.content.commands.Command;
import io.runerealm.model.entity.player.Player;
import io.runerealm.util.logging.player.EmptyInventoryLog;

/**
 * Empty the inventory of the player.
 * 
 * @author Emiel
 */
public class Empty extends Command {

	@Override
	public void execute(Player c, String commandName, String input) {
		Server.getLogging().write(new EmptyInventoryLog(c, c.getItems().getInventoryItems()));
		c.getPA().removeAllItems();
		c.sendMessage("You empty your inventory.");
	}
}
