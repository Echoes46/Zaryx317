package io.runerealm.content.commands.admin;

import io.runerealm.content.commands.Command;
import io.runerealm.content.worldevent.WorldEventContainer;
import io.runerealm.content.worldevent.impl.WGWorldEvent;
import io.runerealm.model.entity.player.Player;

public class StartWG extends Command {
    @Override
    public void execute(Player player, String commandName, String input) {
        WorldEventContainer.getInstance().startEvent(new WGWorldEvent());
        player.sendMessage("WeaponGames will start soon.");
    }
}
