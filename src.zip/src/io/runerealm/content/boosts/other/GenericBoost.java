package io.runerealm.content.boosts.other;

import io.runerealm.content.boosts.BoostType;
import io.runerealm.content.boosts.Booster;
import io.runerealm.model.entity.player.Player;

public abstract class GenericBoost implements Booster<Player> {
    @Override
    public BoostType getType() {
        return BoostType.GENERIC;
    }
}
