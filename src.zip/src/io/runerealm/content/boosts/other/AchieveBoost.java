package io.runerealm.content.boosts.other;

import io.runerealm.content.bosses.hespori.Hespori;
import io.runerealm.model.entity.player.Player;
import io.runerealm.util.Misc;

public class AchieveBoost extends GenericBoost {
    @Override
    public String getDescription() {
        return "x2 Achieve Progress (" + Misc.cyclesToDottedTime((int) Hespori.ACHIEVE_TIMER) + ")";
    }

    @Override
    public boolean applied(Player player) {
        return Hespori.ACHIEVE_TIMER > 0;
    }
}

