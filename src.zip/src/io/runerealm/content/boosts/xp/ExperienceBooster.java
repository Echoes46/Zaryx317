package io.runerealm.content.boosts.xp;

import io.runerealm.content.boosts.BoostType;
import io.runerealm.content.boosts.Booster;
import io.runerealm.content.boosts.PlayerSkillWrapper;

public abstract class ExperienceBooster implements Booster<PlayerSkillWrapper> {

    @Override
    public BoostType getType() {
        return BoostType.EXPERIENCE;
    }

}
