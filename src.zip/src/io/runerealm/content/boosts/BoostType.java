package io.runerealm.content.boosts;

public enum BoostType {
    EXPERIENCE, GENERIC
}
