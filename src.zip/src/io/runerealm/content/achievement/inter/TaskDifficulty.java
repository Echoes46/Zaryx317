package io.runerealm.content.achievement.inter;

/**
 * Used for filtering.
 */
public enum TaskDifficulty {
    NONE, BEGINNER, INTERMEDIATE, EXPERT, LEGENDARY
}
