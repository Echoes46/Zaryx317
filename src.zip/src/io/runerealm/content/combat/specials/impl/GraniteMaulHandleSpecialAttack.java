package io.runerealm.content.combat.specials.impl;

import io.runerealm.content.combat.Damage;
import io.runerealm.content.combat.specials.Special;
import io.runerealm.model.Items;
import io.runerealm.model.entity.Entity;
import io.runerealm.model.entity.player.Player;

public class GraniteMaulHandleSpecialAttack extends Special {

    public GraniteMaulHandleSpecialAttack() {
        super(5.0, 1, 1, new int[]{24225, 24227});
    }

    @Override
    public void activate(Player player, Entity target, Damage damage) {

    }

    @Override
    public void hit(Player player, Entity target, Damage damage) {

    }
}