package io.runerealm.content.combat.specials.impl;

import io.runerealm.content.combat.Damage;
import io.runerealm.content.combat.specials.Special;
import io.runerealm.model.entity.Entity;
import io.runerealm.model.entity.player.Player;

public class StatiusWarhammer extends Special {

	public StatiusWarhammer() {
		super(3.5, 1.25, 0.25, new int[] { 22622 });
	}

	@Override
	public void activate(Player player, Entity target, Damage damage) {
		player.gfx0(1241);
		player.startAnimation(1378);
	}

	@Override
	public void hit(Player player, Entity target, Damage damage) {
		new DragonWarhammer().hit(player, target, damage);
	}

}
