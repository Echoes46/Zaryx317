package io.runerealm.content.combat.npc;

import io.runerealm.model.entity.Entity;
import io.runerealm.model.entity.npc.NPC;
import io.runerealm.model.entity.player.Player;

import static io.runerealm.content.bosses.nightmare.NightmareStatusNPC.npc;

public class PlayerCombatAttack {

    private final Player player;
    private final Entity victim;

    public PlayerCombatAttack(Player player, Entity victim) {
        this.player = player;
        this.victim = getNpc();
    }

    public NPC getNpc() {
        return npc;
    }

    public Entity getVictim() {
        return victim;
    }

}
