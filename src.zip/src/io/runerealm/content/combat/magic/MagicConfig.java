package io.runerealm.content.combat.magic;

public class MagicConfig {

}