package io.runerealm.content.combat.magic;

import io.runerealm.content.combat.Damage;
import io.runerealm.content.combat.range.RangeData;
import io.runerealm.model.cycleevent.CycleEvent;
import io.runerealm.model.cycleevent.CycleEventContainer;
import io.runerealm.model.cycleevent.CycleEventHandler;
import io.runerealm.model.entity.Entity;
import io.runerealm.model.entity.npc.NPC;
import io.runerealm.model.entity.player.Player;

public class TumekenShadow {

    public static final int COMBAT_SPELL_INDEX = 100;

}
