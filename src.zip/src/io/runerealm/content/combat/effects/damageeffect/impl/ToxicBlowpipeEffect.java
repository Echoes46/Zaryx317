package io.runerealm.content.combat.effects.damageeffect.impl;

import java.util.Optional;

import io.runerealm.content.combat.Damage;
import io.runerealm.content.combat.effects.damageeffect.DamageEffect;
import io.runerealm.model.entity.HealthStatus;
import io.runerealm.model.entity.npc.NPC;
import io.runerealm.model.entity.player.Player;
import io.runerealm.util.Misc;

public class ToxicBlowpipeEffect implements DamageEffect {

	@Override
	public void execute(Player attacker, Player defender, Damage damage) {
		defender.getHealth().proposeStatus(HealthStatus.VENOM, 6, Optional.of(attacker));
	}

	@Override
	public void execute(Player attacker, NPC defender, Damage damage) {
		defender.getHealth().proposeStatus(HealthStatus.VENOM, 6, Optional.of(attacker));
	}

	@Override
	public boolean isExecutable(Player operator) {
		return operator.getItems().isWearingItem(12926) && Misc.random(3) == 0 || operator.getItems().isWearingItem(28688) && Misc.random(3) == 0;
	}

}
