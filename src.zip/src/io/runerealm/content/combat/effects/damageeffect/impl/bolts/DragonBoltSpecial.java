package io.runerealm.content.combat.effects.damageeffect.impl.bolts;

import io.runerealm.content.combat.Damage;
import io.runerealm.content.combat.effects.damageeffect.DamageBoostingEffect;
import io.runerealm.content.combat.range.RangeData;
import io.runerealm.model.Items;
import io.runerealm.model.SoundType;
import io.runerealm.model.entity.Entity;
import io.runerealm.model.entity.npc.NPC;
import io.runerealm.model.entity.player.Player;
import io.runerealm.util.Misc;

public class DragonBoltSpecial implements DamageBoostingEffect {

	@Override
	public void execute(Player attacker, Player defender, Damage damage) {
		if (defender.antifireDelay > 0 || defender.getItems().isWearingAnyItem(11283, 11284, 1540) ||
				defender.getPerkSytem().gameItems.stream().anyMatch(item -> item.getId() == 33118) && defender.wildLevel < 0) {
			return;
		}
		int change = Misc.random((int) (damage.getAmount() * 1.45));
		damage.setAmount(change);
		RangeData.createCombatGraphic(defender, 756, false);
		attacker.getPA().sendSound(2915, SoundType.AREA_SOUND);
	}

	@Override
	public void execute(Player attacker, NPC defender, Damage damage) {
		if (defender.getDefinition().getName() != null && defender.getDefinition().getName().toLowerCase().contains("dragon")) {
			return;
		}
		attacker.ignoreDefence = true;
		RangeData.createCombatGraphic(defender, 756, false);
	}

	@Override
	public boolean isExecutable(Player operator) {
		return RangeData.boltSpecialAvailable(operator, Items.DRAGONSTONE_BOLTS_E, Items.DRAGONSTONE_DRAGON_BOLTS_E);
	}

	@Override
	public double getMaxHitBoost(Player attacker, Entity defender) {
		return 0.45;
	}

}
