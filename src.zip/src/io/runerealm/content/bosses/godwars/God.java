package io.runerealm.content.bosses.godwars;

public enum God {
	SARADOMIN,
	ZAMORAK,
	BANDOS,
	ARMADYL
}
