package io.runerealm.content.bosses;

import com.google.common.collect.Lists;
import com.twilio.twiml.voice.Play;
import io.runerealm.Server;
import io.runerealm.content.battlepass.Pass;
import io.runerealm.content.bosses.nex.attacks.IceBarrage;
import io.runerealm.content.combat.Hitmark;
import io.runerealm.content.combat.death.NPCDeath;
import io.runerealm.content.combat.npc.NPCAutoAttackBuilder;
import io.runerealm.model.Animation;
import io.runerealm.model.CombatType;
import io.runerealm.model.ProjectileBaseBuilder;
import io.runerealm.model.entity.npc.NPC;
import io.runerealm.model.entity.npc.NPCSpawning;
import io.runerealm.model.entity.player.Player;
import io.runerealm.model.entity.player.PlayerHandler;
import io.runerealm.model.entity.player.mode.ModeType;
import io.runerealm.sql.dailytracker.TrackerType;
import io.runerealm.util.Location3D;
import io.runerealm.util.Misc;
import io.runerealm.util.discord.Discord;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class ForestGuardian {

    public static boolean spawned;
    public static boolean alive;
    public static HashMap<Player, Integer> damageCount = new HashMap<>();
    public static List<Player> targets;

    public static void handleDeath(NPC npc) {
        for (Player p : PlayerHandler.getPlayers()) {
            if (p.getPosition().inForestGuardian() && p.getMode().getType() == ModeType.WILDYMAN || p.getPosition().inForestGuardian() && p.getMode().getType() == ModeType.WILDYMAN ) {
                Server.getDropManager().create(p, npc, new Location3D(3445, 3838, 0), 1, 13201);
                p.getPA().movePlayer(3445, 3838, 0);
                return;
             } else {
                if (p.getPosition().inForestGuardian()) {
                    Server.getDropManager().create(p, npc, new Location3D(2080, 5969, 0), 1, 13201);
                    p.getPA().movePlayer(2080, 5969, 0);
                    return;
            }
        }
    }
}}
