package io.runerealm.content.bosses.nightmare.phase;

import io.runerealm.content.bosses.nightmare.Nightmare;
import io.runerealm.content.bosses.nightmare.NightmareAttack;
import io.runerealm.content.bosses.nightmare.NightmarePhase;
import io.runerealm.content.bosses.nightmare.NightmareStatus;
import io.runerealm.content.bosses.nightmare.attack.GraspingClaws;
import io.runerealm.content.bosses.nightmare.attack.Spores;
import io.runerealm.content.bosses.nightmare.attack.Surge;

public class Phase3 implements NightmarePhase {


    @Override
    public void start(Nightmare nightmare) {

    }

    @Override
    public NightmareStatus getStatus() {
        return NightmareStatus.PHASE_3;
    }

    @Override
    public NightmareAttack[] getAttacks() {
        return new NightmareAttack[] { new GraspingClaws(), new Spores(), new Surge() };
    }
}
