package io.runerealm.content.bosses.leviathan;

/**
 * @author RuneRealm
 * @social Discord: RuneRealm
 * Website: www.RuneRealm.fun
 * @since 23/03/2024
 */
public class TheLeviathan {



}
