package io.runerealm.content.bosses.hespori;

import java.util.concurrent.TimeUnit;

import io.runerealm.content.QuestTab;
import io.runerealm.content.bonus.DoubleExperience;
import io.runerealm.content.wogw.Wogw;
import io.runerealm.model.entity.player.Player;
import io.runerealm.model.entity.player.PlayerHandler;
import io.runerealm.util.discord.Discord;

public class AttasBonus implements HesporiBonus {
    @Override
    public void activate(Player player) {
        Wogw.EXPERIENCE_TIMER += TimeUnit.HOURS.toMillis(1) / 600;
        Discord.writeIngameEvents("```The Attas has sprouted and is granting 1 hours bonus xp!``` <@&1248350477154783321>");
        PlayerHandler.executeGlobalMessage("@bla@[@gre@Hespori@bla@] The Attas has sprouted and is granting 1 hours bonus xp!");
        QuestTab.updateAllQuestTabs();
    }

    @Override
    public void deactivate() {
        Hespori.activeAttasSeed = false;
        Hespori.ATTAS_TIMER = 0;
        updateObject(false);
    }

    @Override
    public boolean canPlant(Player player) {
        if (DoubleExperience.isDoubleExperience()) {
            player.sendMessage("This seed can't be planted during bonus experience.");
            return false;
        }
        return true;
    }

    @Override
    public HesporiBonusPlant getPlant() {
        return HesporiBonusPlant.ATTAS;
    }
}
