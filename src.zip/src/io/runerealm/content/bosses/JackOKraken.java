package io.runerealm.content.bosses;

public class JackOKraken {
}
