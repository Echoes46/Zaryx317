package io.runerealm.content.bosses.kratos;

import io.runerealm.Server;
import io.runerealm.content.combat.npc.NPCAutoAttack;
import io.runerealm.content.combat.npc.NPCAutoAttackBuilder;
import io.runerealm.content.combat.npc.NPCCombatAttack;
import io.runerealm.content.combat.npc.NPCCombatAttackHit;
import io.runerealm.model.Animation;
import io.runerealm.model.CombatType;
import io.runerealm.model.ProjectileBase;
import io.runerealm.model.ProjectileBaseBuilder;
import io.runerealm.model.entity.EntityReference;
import io.runerealm.model.entity.player.Boundary;
import io.runerealm.model.entity.player.ClientGameTimer;
import io.runerealm.model.entity.player.Player;
import io.runerealm.model.entity.player.Position;
import io.runerealm.model.world.objects.GlobalObject;
import io.runerealm.util.Misc;
import io.runerealm.content.bosses.kratos.KratosNpc;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

public class KratosWeb implements Function<KratosNpc, NPCAutoAttack> {

    private static Position[] CORNER_AREAS = {

    };

    private static ProjectileBase projectile() {
        return new ProjectileBaseBuilder()
                .setSendDelay(1)
                .setSpeed(75)
                .setCurve(0)
                .setStartHeight(75)
                .setEndHeight(50)
                .setProjectileId(1687)
                .createProjectileBase();
    }

    @Override
    public NPCAutoAttack apply(KratosNpc nightmare) {
        Consumer<NPCCombatAttackHit> freeze = t -> {
            if (t.getCombatHit().missed())
                return;
            if (!t.getVictim().isFreezable())
                return;
            t.getVictim().attackTimer += 6;
            t.getVictim().freezeTimer = 6;
            t.getVictim().resetWalkingQueue();
            t.getVictim().frozenBy = EntityReference.getReference(t.getNpc());
            if (t.getVictim().isPlayer()) {
                Player p = (Player) t.getVictim();
                ((Player) t.getVictim()).sendMessage("uh oh, youre stuck.");
                ((Player) t.getVictim()).getPA().sendGameTimer(ClientGameTimer.FREEZE, TimeUnit.MILLISECONDS, 600 * 6);
                GlobalObject ground_web = new GlobalObject(34895, p.getX(), p.getY(), p.heightLevel, 2, 10, 5, -1);
                Server.getGlobalObjects().add(ground_web);
            }
            if (nightmare.nextWalk == null) {
                nightmare.nextWalk = CORNER_AREAS[Misc.random(CORNER_AREAS.length - 1)];
            }
            nightmare.resetAttack();
            nightmare.getBehaviour().setAggressive(false);
            nightmare.randomWalk = false;
        };
        Consumer<NPCCombatAttack> hiss = t -> {
            Player p = (Player) t.getVictim();
            t.getNpc().forceChat("Fear me, Now and Forever!");
            nightmare.attackCounter = 0;
        };
        List<Player> players = NPCAutoAttack.getPlayers(nightmare);
        return new NPCAutoAttackBuilder()
                .setSelectPlayersForMultiAttack(new Function<>() {
                    @Override
                    public List<Player> apply(NPCCombatAttack npcCombatAttack) {
                        return players.stream().filter(plr -> Boundary.isIn(plr, Boundary.KRATOS_AREA))
                                .collect(Collectors.toList());
                    }
                })
                .setSelectAutoAttack(new Function<NPCCombatAttack, Boolean>() {
                    @Override
                    public Boolean apply(NPCCombatAttack npcCombatAttack) {
                        return nightmare.attackCounter >= 4;
                    }
                })
                .setAnimation(new Animation(4922))
                .setCombatType(CombatType.SPECIAL)
                .setAttackDelay(4)
                .setHitDelay(3)
                .setDistanceRequiredForAttack(6)
                .setMultiAttack(true)
                .setOnAttack(
                        hiss
                )
                .setOnHit(freeze
                )
                .setProjectile(projectile())
                .createNPCAutoAttack();
    }
}