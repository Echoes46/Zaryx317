package io.runerealm.content.bosses.kratos;

import io.runerealm.content.combat.npc.NPCAutoAttack;
import io.runerealm.content.combat.npc.NPCAutoAttackBuilder;
import io.runerealm.content.combat.npc.NPCCombatAttack;
import io.runerealm.model.Animation;
import io.runerealm.model.CombatType;
import io.runerealm.model.ProjectileBase;
import io.runerealm.model.ProjectileBaseBuilder;

import java.util.function.Function;

public class KratosMinionMage implements Function<KratosNpc, NPCAutoAttack> {

    private static ProjectileBase projectile() {
        return new ProjectileBaseBuilder()
                .setSendDelay(2)
                .setSpeed(25)
                .setStartHeight(40)
                .setProjectileId(1682)
                .createProjectileBase();
    }

    @Override
    public NPCAutoAttack apply(KratosNpc nightmare) {
        return new NPCAutoAttackBuilder()
                .setSelectPlayersForMultiAttack(NPCAutoAttack.getDefaultSelectPlayersForAttack())
                .setAnimation(new Animation(7021))
                .setCombatType(CombatType.MAGE)
                .setMaxHit(15)
                .setHitDelay(3)
                .setAttackDelay(4)
                .setDistanceRequiredForAttack(5)
                .setMultiAttack(false)
                .setPrayerProtectionPercentage(new Function<NPCCombatAttack, Double>() {
                    @Override
                    public Double apply(NPCCombatAttack npcCombatAttack) {
                        return 0.3;
                    }
                })
                .setProjectile(projectile())
                .createNPCAutoAttack();
    }
}
