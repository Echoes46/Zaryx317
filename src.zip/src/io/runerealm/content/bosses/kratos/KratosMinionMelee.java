package io.runerealm.content.bosses.kratos;

import io.runerealm.content.combat.npc.NPCAutoAttack;
import io.runerealm.content.combat.npc.NPCAutoAttackBuilder;
import io.runerealm.content.combat.npc.NPCCombatAttack;
import io.runerealm.model.Animation;
import io.runerealm.model.CombatType;
import io.runerealm.content.bosses.kratos.KratosNpc;

import java.util.function.Function;

public class KratosMinionMelee implements Function<KratosNpc, NPCAutoAttack> {

    @Override
    public NPCAutoAttack apply(KratosNpc nightmare) {
        return new NPCAutoAttackBuilder()
                .setAnimation(new Animation(8147))
                .setCombatType(CombatType.MELEE)
                .setMaxHit(13)
                .setHitDelay(2)
                .setAttackDelay(4)
                .setDistanceRequiredForAttack(1)
                .setPrayerProtectionPercentage(new Function<NPCCombatAttack, Double>() {
                    @Override
                    public Double apply(NPCCombatAttack npcCombatAttack) {
                        return 0.2d;
                    }
                })
                .createNPCAutoAttack();
    }
}