package io.runerealm.content.bosses;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import io.runerealm.model.cycleevent.CycleEvent;
import io.runerealm.model.cycleevent.CycleEventContainer;
import io.runerealm.model.cycleevent.CycleEventHandler;
import io.runerealm.model.entity.npc.NPC;
import io.runerealm.model.entity.npc.NPCHandler;
import io.runerealm.model.entity.npc.NPCSpawning;
import io.runerealm.model.entity.player.Boundary;
import io.runerealm.model.entity.player.Player;
import io.runerealm.model.entity.player.PlayerHandler;
import io.runerealm.util.Misc;

public class Tekton {

	public static void tektonSpecial(Player player) {
		NPC TEKTON = NPCHandler.getNpc(7544);

		if (TEKTON.isDead()) {
			return;
		}

		NPCHandler.npcs[TEKTON.getIndex()].forceChat("RAAAAAAAA!");
		TEKTON.underAttackBy = -1;
		TEKTON.underAttack = false;

		if (Misc.isLucky(5)) {
			DonorBoss3.burnGFX(player, TEKTON);
		}
	}
}
