package io.runerealm.content.bosses.vardorvis;

import io.runerealm.content.commands.owner.Pos;
import io.runerealm.model.entity.player.Position;

/**
 * @author RuneRealm
 * @project RuneRealm-server
 * @social Discord: RuneRealm
 * Website: www.RuneRealm.fun
 * @since 17/01/2024
 */
public enum VardorvisAxePositions {

    NW_SE(new Position(1124, 3421), new Position(1132, 3413)),
    NE_SW(new Position(1132, 3421),new Position(1124, 3413)),
    N_S(new Position(1128, 3421),new Position(1128, 3413)),
    W_E(new Position(1124, 3417),new Position(1132, 3417))

    ;

    public final Position start;
    public final Position finish;

    VardorvisAxePositions(Position start, Position finish) {
        this.start = start;
        this.finish = finish;
    }
}
