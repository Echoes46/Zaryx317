package io.runerealm.content.advancedslayer;

public enum Difficulty {

    EASY, NORMAL, HARD, ANY

}
